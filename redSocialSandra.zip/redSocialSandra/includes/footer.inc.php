<?php
/**
* 
*
* @author Sandra Fernández Ávila
* @version 1.0 
*
*/

// FOOTER DE LA WEB
?>
<br>
<footer class="footer">
    <a href="author.php">Sandra Fernández Ávila ©</a>
    <div>2024-2025</div>
</footer>
